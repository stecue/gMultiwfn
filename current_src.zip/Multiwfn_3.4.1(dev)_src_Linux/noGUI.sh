rm -r noGUI
mkdir noGUI
cp ./Makefile_noGUI noGUI/Makefile
cp *.a noGUI
cp *.F noGUI
for f90 in *.f90
do
grep -v -E "use dislin_d|use plot|use GUI|call drawdomaingui|call drawmolgui|call drawplanegui|call drawisosurgui|call drawmoltopogui|call drawsurfanalysis|call drawbasinintgui|call drawmol|call drawcurve|call drawscatter|call drawmatcolor|call drawplane|call useclrind|metafl|call window|scrmod|imgfmt|call page|disini|hwfont|axslen|axspos|wintit|call ticks|errmod|labdig|call name|setgrf|call graf|setrgb|call dash|call grid|call solid|call curve|call color|box2d|endgrf|xaxgit|disfin|disini|call ticks|errmod|legini|legtit|call frame|legpos|leglin|legpat|swgfnt|setscr|symfil|messag|imgfmt|call center|rlmess|call rline|call height|setxid|winsiz|autres|ax3len|crvmat|getscr|ticpos|call labels|call dot|winsiz|namdis|call linwid|call legend" $f90 -i > noGUI/$f90
done
